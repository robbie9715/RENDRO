
export const chart_data = [
    {
      userPT:"../../public/user/user01.jpg",
      time:"24",
      text:"War moral madness enlightenment aversion oneself. Inexpedient ascetic eternal-return dead suicide. Overcome society noble love.",
      username:"Victoria Alexander",
      follow:"13"
    },
    {
      userPT:"../../public/user/user02.jpg",
      time:"15",
      text:"War moral madness enlightenment aversion oneself. Inexpedient ascetic eternal-return dead suicide. Overcome society noble love.",
      username:"Victoria Alexander",
      follow:"16"
    },
    
  ];
  export default chart_data;
  
  