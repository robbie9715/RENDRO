
// const ref_url = IS_TEST ? IMAGE_URL_LOCAL : IMAGE_URL_ONLINE
// console.log(ref_url)

export const explore_data = [
  {
    img:"../../public/design/01.jpg"
  },
  {
    img:"../../public/design/02.jpg"
  },
  {
    img:"../../public/design/03.jpg"
  },
  {
    img:"../../public/design/04.jpg"
  },
  {
    img:"../../public/design/05.jpg"
  },
  {
    img:"../../public/design/06.jpg"
  },
  {
    img:"../../public/design/07.jpg"
  },
  {
    img:"../../public/design/08.jpg"
  },
  {
    img:"../../public/design/09.jpg"
  },
  {
    img:"../../public/design/09.jpg"
  },
  {
    img:"../../public/design/10.jpg"
  },
 
  {
    img:"../../public/design/11.jpg"
  },
];


export const profiles_data = [
  {
    img:"../../public/design/11.jpg"
  },
  {
    img:"../../public/design/10.jpg"
  },
  {
    img:"../../public/design/09.jpg"
  },
  {
    img:"../../public/design/08.jpg"
  },
  {
    img:"../../public/design/07.jpg"
  },
  {
    img:"../../public/design/06.jpg"
  },
  {
    img:"../../public/design/05.jpg"
  },
  {
    img:"../../public/design/04.jpg"
  },
  {
    img:"../../public/design/03.jpg"
  },
  {
    img:"../../public/design/02.jpg"
  },
  {
    img:"../../public/design/01.jpg"
  },
 
  {
    img:"../../public/design/05.jpg"
  },
];
export const shops_data = [
  {
    img:"../../public/design/03.jpg"
  },
  {
    img:"../../public/design/05.jpg"
  },
  {
    img:"../../public/design/04.jpg"
  },
  {
    img:"../../public/design/03.jpg"
  },
  {
    img:"../../public/design/02.jpg"
  },
  {
    img:"../../public/design/03.jpg"
  },
  {
    img:"../../public/design/07.jpg"
  },
  {
    img:"../../public/design/08.jpg"
  },
  {
    img:"../../public/design/09.jpg"
  },
  {
    img:"../../public/design/07.jpg"
  },
  {
    img:"../../public/design/01.jpg"
  },
 
  {
    img:"../../public/design/03.jpg"
  },
];


