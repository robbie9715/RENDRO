import product01 from "../../public/img/maindesignpack.svg"

export const Product_data = [
    {
     picture:"product01",
    },
    {
     picture:"product01",
    },
    {
    picture:"product01",
    },
    {
    picture:"product01",
    },
    {
    picture:"product01",
    },
    {
    picture:"product01",
    },
   
    
    
  ];
  export default Product_data;
  
  